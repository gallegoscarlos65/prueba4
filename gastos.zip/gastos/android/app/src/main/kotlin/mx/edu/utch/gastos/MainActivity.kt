package mx.edu.utch.gastos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
