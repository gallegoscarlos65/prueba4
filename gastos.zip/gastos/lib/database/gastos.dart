class Gastos {
  final String? concepto;
  final double? cantidad;
  final DateTime? fecha;
  Gastos({required this.concepto, required this.cantidad, required this.fecha});
}
